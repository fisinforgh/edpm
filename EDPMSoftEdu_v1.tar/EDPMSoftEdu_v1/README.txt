1. The name include/odeSEEPM.h was changed by SEEDPM.h
2. the put..sh is an script that place copyright pn files

3. For compiling stand alone version do:

3.1 rootcling -f SEEDPMDict_v1.cxx -c  SEEDPM_v1.h SEEDPMLinkDef_v1.h

then

3.2 g++ -o SEEDPM_v1 SEEDPM_v1.cxx SEEDPMDict_v1.cxx `root-config --cflags --glibs`

4. After doing this:
fisinfor@samsara:~/SEEDPM/3.stand_alone_SEEDPM/EDPMSoftEdu_v1$ g++ -o SEEDPM_v1 SEEDPM_v1.cxx SEEDPMDict.cxx `root-config --cflags --glibs`
/usr/bin/ld: /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/Scrt1.o: in function `_start':
(.text+0x1b): undefined reference to `main'
collect2: error: ld returned 1 exit status
fisinfor@samsara:~/SEEDPM/3.stand_alone_SEEDPM/EDPMSoftEdu_v1$ 

This error is because a int main() function is missing:

int main(int argc, char **argv) {
  TApplication theApp("App",&argc,argv);
  sehdfo_v2();
  theApp.Run();
  return 0;
}

Please add accordingly

4
