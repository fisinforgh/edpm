1. The name include/odeSEEPM.h was changed by SEEDPM.h
2. the put..sh is an script that place copyright pn files
